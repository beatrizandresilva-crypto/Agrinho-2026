// Projeto p5.js - "Agro Forte"
// Tema: Agricultura sustentável e tecnologia no campo

let solX = 100;
let nuvens = [];
let plantas = [];
let tratorX = -200;

function setup() {
  createCanvas(1000, 600);

  // Criar nuvens
  for (let i = 0; i < 6; i++) {
    nuvens.push({
      x: random(width),
      y: random(40, 180),
      velocidade: random(0.3, 1)
    });
  }

  // Criar plantações
  for (let x = 80; x < width; x += 60) {
    plantas.push({
      x: x,
      altura: random(80, 150)
    });
  }
}

function draw() {
  desenharCeu();
  desenharSol();
  desenharNuvens();
  desenharMontanhas();
  desenharCampo();
  desenharPlantacao();
  desenharTrator();
  desenharTitulo();
}

// ----------------------------
// CENÁRIO
// ----------------------------

function desenharCeu() {
  background(120, 200, 255);
}

function desenharSol() {
  fill(255, 220, 0);
  noStroke();
  circle(solX, 90, 90);

  // Movimento suave do sol
  solX += 0.03;
  if (solX > width + 50) {
    solX = -50;
  }
}

function desenharNuvens() {
  for (let n of nuvens) {
    fill(255);
    ellipse(n.x, n.y, 80, 50);
    ellipse(n.x + 30, n.y + 10, 70, 45);
    ellipse(n.x - 30, n.y + 10, 70, 45);

    n.x += n.velocidade;

    if (n.x > width + 100) {
      n.x = -100;
    }
  }
}

function desenharMontanhas() {
  fill(90, 140, 90);

  triangle(0, 350, 200, 150, 400, 350);
  triangle(250, 350, 500, 120, 750, 350);
  triangle(600, 350, 850, 180, 1100, 350);
}

function desenharCampo() {
  fill(70, 170, 70);
  rect(0, 350, width, 250);

  // Linhas da terra
  stroke(100, 70, 40);
  for (let y = 390; y < height; y += 25) {
    line(0, y, width, y);
  }
}

// ----------------------------
// PLANTAÇÃO
// ----------------------------

function desenharPlantacao() {
  for (let p of plantas) {

    // caule
    stroke(20, 120, 20);
    strokeWeight(5);
    line(p.x, 500, p.x, 500 - p.altura);

    // folhas
    fill(30, 180, 50);
    noStroke();

    ellipse(p.x - 10, 500 - p.altura + 30, 25, 12);
    ellipse(p.x + 10, 500 - p.altura + 50, 25, 12);

    // milho
    fill(255, 220, 70);
    ellipse(p.x, 500 - p.altura + 10, 18, 45);
  }
}

// ----------------------------
// TRATOR
// ----------------------------

function desenharTrator() {

  tratorX += 1.2;

  if (tratorX > width + 200) {
    tratorX = -200;
  }

  // Corpo
  fill(220, 0, 0);
  rect(tratorX, 430, 120, 50, 10);

  // Cabine
  fill(180);
  rect(tratorX + 60, 390, 45, 45);

  // Rodas
  fill(40);
  circle(tratorX + 25, 490, 60);
  circle(tratorX + 100, 490, 80);

  fill(120);
  circle(tratorX + 25, 490, 25);
  circle(tratorX + 100, 490, 35);

  // Escape
  fill(50);
  rect(tratorX + 15, 380, 10, 40);

  // Fumaça
  fill(180, 180, 180, 150);
  ellipse(tratorX + 20, 360, 25);
  ellipse(tratorX + 35, 340, 20);
}

// ----------------------------
// TÍTULO
// ----------------------------

function desenharTitulo() {
  fill(255);
  stroke(0);
  strokeWeight(3);

  textAlign(CENTER);
  textSize(38);
  text("AGRO FORTE 🌾🚜", width / 2, 60);

  textSize(20);
  noStroke();
  fill(20);

  text(
    "Tecnologia, sustentabilidade e produção no campo",
    width / 2,
    95
  );
}